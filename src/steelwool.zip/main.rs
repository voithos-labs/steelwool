// for testing
use steelwool::providers::ollama::create_ollama_adapter;
use steelwool::{
    ContentType, ContextBuilder, Message, MessageRole, PromptResponse, ProviderAdapter, StopReason,
    Tool,
};

#[tokio::main]
async fn main() {
    println!("🧶 steelwool test with Ollama");

    // Create an Ollama adapter for llama2
    let model_name = "gemma3".to_string();
    let adapter = create_ollama_adapter(model_name);

    // Create a context with a user message
    let context = ContextBuilder { history: vec![] }.add_message(Message {
        role: MessageRole::User,
        content: "Explain quantum computing in 3 simple sentences.".to_string(),
        content_type: ContentType::Text,
    });

    // System message to guide the model's behavior
    let system_message =
        "You are a helpful, concise assistant. Keep your answers brief.".to_string();

    // Send the request to the model
    println!("Sending request to Ollama...");
    let response = context
        .send(adapter, system_message, 1000, None)
        .await
        .resolve_without()
        .await;

    // Print the model's response
    println!("\n--- Response ---");
    for message in response.history {
        let role = match message.role {
            MessageRole::User => "User",
            MessageRole::Model => "Assistant",
            MessageRole::System => "System",
            MessageRole::Function => "Function",
            MessageRole::Tool => "Tool",
        };

        println!("{}: {}", role, message.content);
    }
}
